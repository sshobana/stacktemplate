import boto3
cf_client = boto3.client('cloudformation')
cf_client.create_stack(
    StackName='your-stack',
    TemplateURL='https://s3.amazonaws.com/cloudformationlambda/customauth.json'
)
